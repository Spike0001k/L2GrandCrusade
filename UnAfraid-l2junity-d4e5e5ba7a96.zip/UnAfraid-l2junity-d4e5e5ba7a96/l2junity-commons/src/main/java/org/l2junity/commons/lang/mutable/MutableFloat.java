/*
 * Copyright (C) 2004-2016 L2J Unity
 * 
 * This file is part of L2J Unity.
 * 
 * L2J Unity is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * L2J Unity is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package org.l2junity.commons.lang.mutable;

/**
 * A mutable <code>float</code> wrapper.
 * <p>
 * Note that as MutableFloat does not extend Float, it is not treated by String.format as a Float parameter.
 * @see Float
 * @since 2.1
 */
public class MutableFloat extends Number implements Comparable<MutableFloat>, Mutable<Number>
{
	/**
	 * Required for serialization support.
	 * @see java.io.Serializable
	 */
	private static final long serialVersionUID = 5787169186L;
	
	/** The mutable value. */
	private float _value;
	
	/**
	 * Constructs a new MutableFloat with the default value of zero.
	 */
	public MutableFloat()
	{
		super();
	}
	
	/**
	 * Constructs a new MutableFloat with the specified value.
	 * @param value the initial value to store
	 */
	public MutableFloat(final float value)
	{
		super();
		_value = value;
	}
	
	/**
	 * Constructs a new MutableFloat with the specified value.
	 * @param value the initial value to store, not null
	 * @throws NullPointerException if the object is null
	 */
	public MutableFloat(final Number value)
	{
		super();
		_value = value.floatValue();
	}
	
	/**
	 * Constructs a new MutableFloat parsing the given string.
	 * @param value the string to parse, not null
	 * @throws NumberFormatException if the string cannot be parsed into a float
	 * @since 2.5
	 */
	public MutableFloat(final String value) throws NumberFormatException
	{
		super();
		_value = Float.parseFloat(value);
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Gets the value as a Float instance.
	 * @return the value as a Float, never null
	 */
	@Override
	public Float getValue()
	{
		return Float.valueOf(_value);
	}
	
	/**
	 * Sets the value.
	 * @param value the value to set
	 */
	public void setValue(final float value)
	{
		_value = value;
	}
	
	/**
	 * Sets the value from any Number instance.
	 * @param value the value to set, not null
	 * @throws NullPointerException if the object is null
	 */
	@Override
	public void setValue(final Number value)
	{
		_value = value.floatValue();
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Checks whether the float value is the special NaN value.
	 * @return true if NaN
	 */
	public boolean isNaN()
	{
		return Float.isNaN(_value);
	}
	
	/**
	 * Checks whether the float value is infinite.
	 * @return true if infinite
	 */
	public boolean isInfinite()
	{
		return Float.isInfinite(_value);
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Increments the value.
	 * @since Commons Lang 2.2
	 */
	public void increment()
	{
		_value++;
	}
	
	/**
	 * Increments this instance's value by 1; this method returns the value associated with the instance immediately prior to the increment operation. This method is not thread safe.
	 * @return the value associated with the instance before it was incremented
	 * @since 3.5
	 */
	public float getAndIncrement()
	{
		final float last = _value;
		_value++;
		return last;
	}
	
	/**
	 * Increments this instance's value by 1; this method returns the value associated with the instance immediately after the increment operation. This method is not thread safe.
	 * @return the value associated with the instance after it is incremented
	 * @since 3.5
	 */
	public float incrementAndGet()
	{
		_value++;
		return _value;
	}
	
	/**
	 * Decrements the value.
	 * @since Commons Lang 2.2
	 */
	public void decrement()
	{
		_value--;
	}
	
	/**
	 * Decrements this instance's value by 1; this method returns the value associated with the instance immediately prior to the decrement operation. This method is not thread safe.
	 * @return the value associated with the instance before it was decremented
	 * @since 3.5
	 */
	public float getAndDecrement()
	{
		final float last = _value;
		_value--;
		return last;
	}
	
	/**
	 * Decrements this instance's value by 1; this method returns the value associated with the instance immediately after the decrement operation. This method is not thread safe.
	 * @return the value associated with the instance after it is decremented
	 * @since 3.5
	 */
	public float decrementAndGet()
	{
		_value--;
		return _value;
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Adds a value to the value of this instance.
	 * @param operand the value to add, not null
	 * @since Commons Lang 2.2
	 */
	public void add(final float operand)
	{
		_value += operand;
	}
	
	/**
	 * Adds a value to the value of this instance.
	 * @param operand the value to add, not null
	 * @throws NullPointerException if the object is null
	 * @since Commons Lang 2.2
	 */
	public void add(final Number operand)
	{
		_value += operand.floatValue();
	}
	
	/**
	 * Subtracts a value from the value of this instance.
	 * @param operand the value to subtract
	 * @since Commons Lang 2.2
	 */
	public void subtract(final float operand)
	{
		_value -= operand;
	}
	
	/**
	 * Subtracts a value from the value of this instance.
	 * @param operand the value to subtract, not null
	 * @throws NullPointerException if the object is null
	 * @since Commons Lang 2.2
	 */
	public void subtract(final Number operand)
	{
		_value -= operand.floatValue();
	}
	
	/**
	 * Increments this instance's value by {@code operand}; this method returns the value associated with the instance immediately after the addition operation. This method is not thread safe.
	 * @param operand the quantity to add, not null
	 * @return the value associated with this instance after adding the operand
	 * @since 3.5
	 */
	public float addAndGet(final float operand)
	{
		_value += operand;
		return _value;
	}
	
	/**
	 * Increments this instance's value by {@code operand}; this method returns the value associated with the instance immediately after the addition operation. This method is not thread safe.
	 * @param operand the quantity to add, not null
	 * @throws NullPointerException if {@code operand} is null
	 * @return the value associated with this instance after adding the operand
	 * @since 3.5
	 */
	public float addAndGet(final Number operand)
	{
		_value += operand.floatValue();
		return _value;
	}
	
	/**
	 * Increments this instance's value by {@code operand}; this method returns the value associated with the instance immediately prior to the addition operation. This method is not thread safe.
	 * @param operand the quantity to add, not null
	 * @return the value associated with this instance immediately before the operand was added
	 * @since 3.5
	 */
	public float getAndAdd(final float operand)
	{
		final float last = _value;
		_value += operand;
		return last;
	}
	
	/**
	 * Increments this instance's value by {@code operand}; this method returns the value associated with the instance immediately prior to the addition operation. This method is not thread safe.
	 * @param operand the quantity to add, not null
	 * @throws NullPointerException if {@code operand} is null
	 * @return the value associated with this instance immediately before the operand was added
	 * @since 3.5
	 */
	public float getAndAdd(final Number operand)
	{
		final float last = _value;
		_value += operand.floatValue();
		return last;
	}
	
	// -----------------------------------------------------------------------
	// shortValue and byteValue rely on Number implementation
	/**
	 * Returns the value of this MutableFloat as an int.
	 * @return the numeric value represented by this object after conversion to type int.
	 */
	@Override
	public int intValue()
	{
		return (int) _value;
	}
	
	/**
	 * Returns the value of this MutableFloat as a long.
	 * @return the numeric value represented by this object after conversion to type long.
	 */
	@Override
	public long longValue()
	{
		return (long) _value;
	}
	
	/**
	 * Returns the value of this MutableFloat as a float.
	 * @return the numeric value represented by this object after conversion to type float.
	 */
	@Override
	public float floatValue()
	{
		return _value;
	}
	
	/**
	 * Returns the value of this MutableFloat as a double.
	 * @return the numeric value represented by this object after conversion to type double.
	 */
	@Override
	public double doubleValue()
	{
		return _value;
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Gets this mutable as an instance of Float.
	 * @return a Float instance containing the value from this mutable, never null
	 */
	public Float toFloat()
	{
		return Float.valueOf(floatValue());
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Compares this object against some other object. The result is <code>true</code> if and only if the argument is not <code>null</code> and is a <code>Float</code> object that represents a <code>float</code> that has the identical bit pattern to the bit pattern of the <code>float</code>
	 * represented by this object. For this purpose, two float values are considered to be the same if and only if the method {@link Float#floatToIntBits(float)}returns the same int value when applied to each.
	 * <p>
	 * Note that in most cases, for two instances of class <code>Float</code>,<code>f1</code> and <code>f2</code>, the value of <code>f1.equals(f2)</code> is <code>true</code> if and only if <blockquote>
	 * 
	 * <pre>
	 * f1.floatValue() == f2.floatValue()
	 * </pre>
	 * 
	 * </blockquote>
	 * <p>
	 * also has the value <code>true</code>. However, there are two exceptions:
	 * <ul>
	 * <li>If <code>f1</code> and <code>f2</code> both represent <code>Float.NaN</code>, then the <code>equals</code> method returns <code>true</code>, even though <code>Float.NaN==Float.NaN</code> has the value <code>false</code>.
	 * <li>If <code>f1</code> represents <code>+0.0f</code> while <code>f2</code> represents <code>-0.0f</code>, or vice versa, the <code>equal</code> test has the value <code>false</code>, even though <code>0.0f==-0.0f</code> has the value <code>true</code>.
	 * </ul>
	 * This definition allows hashtables to operate properly.
	 * @param obj the object to compare with, null returns false
	 * @return <code>true</code> if the objects are the same; <code>false</code> otherwise.
	 * @see java.lang.Float#floatToIntBits(float)
	 */
	@Override
	public boolean equals(final Object obj)
	{
		return (obj instanceof MutableFloat) && (Float.floatToIntBits(((MutableFloat) obj)._value) == Float.floatToIntBits(_value));
	}
	
	/**
	 * Returns a suitable hash code for this mutable.
	 * @return a suitable hash code
	 */
	@Override
	public int hashCode()
	{
		return Float.floatToIntBits(_value);
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Compares this mutable to another in ascending order.
	 * @param other the other mutable to compare to, not null
	 * @return negative if this is less, zero if equal, positive if greater
	 */
	@Override
	public int compareTo(final MutableFloat other)
	{
		return Float.compare(_value, other._value);
	}
	
	// -----------------------------------------------------------------------
	/**
	 * Returns the String value of this mutable.
	 * @return the mutable value as a string
	 */
	@Override
	public String toString()
	{
		return String.valueOf(_value);
	}
}
