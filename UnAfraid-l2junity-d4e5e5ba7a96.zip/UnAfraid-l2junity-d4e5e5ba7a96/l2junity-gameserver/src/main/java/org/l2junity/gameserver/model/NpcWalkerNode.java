/*
 * Copyright (C) 2004-2015 L2J Unity
 * 
 * This file is part of L2J Unity.
 * 
 * L2J Unity is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * L2J Unity is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package org.l2junity.gameserver.model;

import org.l2junity.gameserver.network.client.send.string.NpcStringId;

/**
 * @author Rayan RPG, JIV
 * @since 927
 */
public class NpcWalkerNode extends Location
{
	private static final long serialVersionUID = 6179417606301402588L;
	private final String _chatString;
	private final NpcStringId _npcString;
	private final int _delay;
	private final boolean _runToLocation;
	
	public NpcWalkerNode(int moveX, int moveY, int moveZ, int delay, boolean runToLocation, NpcStringId npcString, String chatText)
	{
		super(moveX, moveY, moveZ);
		_delay = delay;
		_runToLocation = runToLocation;
		_npcString = npcString;
		_chatString = ((chatText == null) ? "" : chatText);
	}
	
	public int getDelay()
	{
		return _delay;
	}
	
	public boolean runToLocation()
	{
		return _runToLocation;
	}
	
	public NpcStringId getNpcString()
	{
		return _npcString;
	}
	
	public String getChatText()
	{
		if (_npcString != null)
		{
			throw new IllegalStateException("npcString is defined for walker route!");
		}
		return _chatString;
	}
}
